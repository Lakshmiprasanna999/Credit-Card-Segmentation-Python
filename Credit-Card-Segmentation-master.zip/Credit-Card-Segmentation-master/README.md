# Credit-Card-Segmentation
This case requires trainees to develop a customer segmentation to define marketing strategy.
